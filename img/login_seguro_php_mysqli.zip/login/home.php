<?php require_once 'templates/header.php';?>
	<div class="content">
     	<div class="container">
     		<div class="col-md-8 col-sm-8 col-xs-12">
     			<div class="well text-center">
	     			<p>Sonríe cada vez que pueda.</p>
					<p>No porque la vida ha sido fácil o perfecta,</p>
					<p>o exactamente como se había previsto,</p>
					<p>sino porque decidiste ser feliz</p>
					<p>y agradecido por todas las cosas buenas que tienes</p>
					<p>y todos los problemas que usted sabe que no tiene.</p>
     			</div>
     			<br>
     			
     			
     		</div>
     		<?php require_once 'templates/sidebar.php';?>
     		
     	</div>
    </div> <!-- /container -->
<?php require_once 'templates/footer.php';?>
	
